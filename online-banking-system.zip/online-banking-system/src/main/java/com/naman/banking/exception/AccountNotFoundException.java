package com.naman.banking.exception;

/** No such account, or the account is not owned by the user. */
public class AccountNotFoundException extends BankingException {
    public AccountNotFoundException(String message) {
        super(message);
    }
}
