package com.naman.banking.service;

import com.naman.banking.model.Account;
import com.naman.banking.model.AccountType;
import com.naman.banking.model.Transaction;

import java.math.BigDecimal;
import java.util.List;

/**
 * Everything the UI layer is allowed to ask of the banking backend.
 *
 * <p>The console app (and any future web/REST front end) depends only on this
 * interface, so the backend can be swapped (in-memory, database, ...) without
 * touching the UI - this keeps the layers loosely coupled.
 *
 * <p>Every call needs a session token. Money-moving calls also need a unique
 * {@code requestId}; re-sending the same id is rejected as a duplicate.
 */
public interface TransactionProcessor {

    Account openAccount(String token, AccountType type, BigDecimal initialDeposit, String requestId);

    Transaction deposit(String token, String accountNumber, BigDecimal amount, String remarks, String requestId);

    Transaction withdraw(String token, String accountNumber, BigDecimal amount, String remarks, String requestId);

    BigDecimal getBalance(String token, String accountNumber);

    List<Transaction> getMiniStatement(String token, String accountNumber, int count);

    BigDecimal applyMonthlyInterest(String token, String accountNumber, String requestId);

    List<Account> listAccounts(String token);
}
