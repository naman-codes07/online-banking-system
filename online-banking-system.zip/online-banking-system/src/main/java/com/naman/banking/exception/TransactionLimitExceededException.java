package com.naman.banking.exception;

/** A per-transaction or daily withdrawal limit was exceeded. */
public class TransactionLimitExceededException extends BankingException {
    public TransactionLimitExceededException(String message) {
        super(message);
    }
}
