package com.naman.banking.model;

public enum AccountType {
    SAVINGS, CURRENT
}
