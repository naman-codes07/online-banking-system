package com.naman.banking.exception;

/** Input failed validation (bad amount, name, PIN, email...). */
public class InvalidInputException extends BankingException {
    public InvalidInputException(String message) {
        super(message);
    }
}
