package com.naman.banking.model;

public enum TransactionType {
    DEPOSIT, WITHDRAWAL, INTEREST, OPENING_BALANCE
}
