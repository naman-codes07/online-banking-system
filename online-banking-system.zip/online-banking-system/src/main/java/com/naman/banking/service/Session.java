package com.naman.banking.service;

import com.naman.banking.model.User;

import java.time.Instant;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** A logged-in session. Remembers used request ids so a resubmitted form is rejected. */
public class Session {
    private final String token = UUID.randomUUID().toString();
    private final User user;
    private volatile Instant lastAccess;
    private final Set<String> usedRequestIds = ConcurrentHashMap.newKeySet();

    Session(User user, Instant now) {
        this.user = user;
        this.lastAccess = now;
    }

    public String getToken() { return token; }
    public User getUser() { return user; }
    Instant getLastAccess() { return lastAccess; }
    void touch(Instant now) { this.lastAccess = now; }

    /** Atomic: returns true only for the first caller with this id. */
    boolean registerRequest(String requestId) {
        return usedRequestIds.add(requestId);
    }
}
