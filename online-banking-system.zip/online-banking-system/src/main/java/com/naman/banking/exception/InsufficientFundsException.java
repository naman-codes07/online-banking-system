package com.naman.banking.exception;

/** The account rules do not allow this withdrawal. */
public class InsufficientFundsException extends BankingException {
    public InsufficientFundsException(String message) {
        super(message);
    }
}
