package com.naman.banking.exception;

/** Wrong e-mail or PIN. */
public class AuthenticationException extends BankingException {
    public AuthenticationException(String message) {
        super(message);
    }
}
