package com.naman.banking.model;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/** Immutable record of one money movement. */
public final class Transaction {
    private final String id = UUID.randomUUID().toString();
    private final String accountNumber;
    private final TransactionType type;
    private final BigDecimal amount;
    private final BigDecimal balanceAfter;
    private final String remarks;
    private final Instant timestamp;

    public Transaction(String accountNumber, TransactionType type, BigDecimal amount,
                       BigDecimal balanceAfter, String remarks, Instant timestamp) {
        this.accountNumber = accountNumber;
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
        this.remarks = remarks;
        this.timestamp = timestamp;
    }

    public String getId() { return id; }
    public String getAccountNumber() { return accountNumber; }
    public TransactionType getType() { return type; }
    public BigDecimal getAmount() { return amount; }
    public BigDecimal getBalanceAfter() { return balanceAfter; }
    public String getRemarks() { return remarks; }
    public Instant getTimestamp() { return timestamp; }

    @Override
    public String toString() {
        return String.format("%s | %-15s | %12s | bal %12s | %s",
                timestamp.toString().substring(0, 19).replace('T', ' '),
                type, amount.toPlainString(), balanceAfter.toPlainString(), remarks);
    }
}
