package com.naman.banking.util;

import com.naman.banking.exception.InvalidInputException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.regex.Pattern;

/** Central place for input validation so every layer applies the same rules. */
public final class Validator {

    public static final BigDecimal MAX_TRANSACTION_AMOUNT = new BigDecimal("10000000.00");
    private static final Pattern NAME = Pattern.compile("^[A-Za-z][A-Za-z .'-]{1,49}$");
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PIN = Pattern.compile("^\\d{4,6}$");
    private static final int MAX_REMARKS = 100;

    private Validator() { }

    public static String requireName(String name) {
        if (name == null || !NAME.matcher(name.trim()).matches()) {
            throw new InvalidInputException("Name must be 2-50 letters (spaces, . ' - allowed).");
        }
        return name.trim();
    }

    public static String requireEmail(String email) {
        if (email == null || !EMAIL.matcher(email.trim()).matches()) {
            throw new InvalidInputException("Invalid e-mail address.");
        }
        return email.trim().toLowerCase();
    }

    public static String requirePin(String pin) {
        if (pin == null || !PIN.matcher(pin).matches()) {
            throw new InvalidInputException("PIN must be 4-6 digits.");
        }
        return pin;
    }

    /** Amount must be positive, have at most 2 decimals and not exceed the max. */
    public static BigDecimal requireAmount(BigDecimal amount) {
        if (amount == null) {
            throw new InvalidInputException("Amount is required.");
        }
        if (amount.signum() <= 0) {
            throw new InvalidInputException("Amount must be greater than zero.");
        }
        if (amount.stripTrailingZeros().scale() > 2) {
            throw new InvalidInputException("Amount can have at most 2 decimal places.");
        }
        if (amount.compareTo(MAX_TRANSACTION_AMOUNT) > 0) {
            throw new InvalidInputException("Amount exceeds the maximum of " + MAX_TRANSACTION_AMOUNT + ".");
        }
        return amount.setScale(2, RoundingMode.HALF_UP);
    }

    /** Parses user text into an amount; rejects anything that is not a plain number. */
    public static BigDecimal parseAmount(String text) {
        if (text == null || text.isBlank()) {
            throw new InvalidInputException("Amount is required.");
        }
        try {
            return requireAmount(new BigDecimal(text.trim()));
        } catch (NumberFormatException e) {
            throw new InvalidInputException("'" + text.trim() + "' is not a valid number.");
        }
    }

    /** Remarks are optional; control characters are stripped and length is capped. */
    public static String cleanRemarks(String remarks) {
        if (remarks == null) {
            return "";
        }
        String cleaned = remarks.replaceAll("\\p{Cntrl}", " ").trim();
        if (cleaned.length() > MAX_REMARKS) {
            throw new InvalidInputException("Remarks cannot exceed " + MAX_REMARKS + " characters.");
        }
        return cleaned;
    }

    public static String requireRequestId(String requestId) {
        if (requestId == null || requestId.isBlank()) {
            throw new InvalidInputException("Request id is required.");
        }
        return requestId;
    }
}
