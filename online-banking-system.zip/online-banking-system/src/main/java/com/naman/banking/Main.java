package com.naman.banking;

import com.naman.banking.exception.BankingException;
import com.naman.banking.model.Account;
import com.naman.banking.model.AccountType;
import com.naman.banking.model.Transaction;
import com.naman.banking.service.AuthService;
import com.naman.banking.service.BankingService;
import com.naman.banking.service.SessionManager;
import com.naman.banking.service.TransactionProcessor;
import com.naman.banking.util.Validator;

import java.math.BigDecimal;
import java.time.Clock;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

/** Console front end. It talks to the backend only through {@link TransactionProcessor}. */
public class Main {
    private final Scanner in = new Scanner(System.in);
    private final AuthService auth;
    private final TransactionProcessor bank;
    private String token;

    public Main() {
        Clock clock = Clock.systemDefaultZone();
        SessionManager sessions = new SessionManager(clock);
        this.auth = new AuthService(sessions);
        this.bank = new BankingService(sessions, clock);
    }

    public static void main(String[] args) {
        new Main().run();
    }

    private void run() {
        System.out.println("=== Online Banking System ===");
        while (true) {
            try {
                if (token == null) {
                    if (!loggedOutMenu()) {
                        return;
                    }
                } else {
                    loggedInMenu();
                }
            } catch (BankingException e) {
                System.out.println("  ! " + e.getMessage());
                if (e instanceof com.naman.banking.exception.SessionException) {
                    token = null;
                }
            }
        }
    }

    private boolean loggedOutMenu() {
        System.out.println("\n1) Register   2) Login   0) Exit");
        switch (ask("Choose")) {
            case "1" -> {
                auth.register(ask("Full name"), ask("E-mail"), ask("PIN (4-6 digits)"));
                System.out.println("  Registered. You can log in now.");
            }
            case "2" -> {
                token = auth.login(ask("E-mail"), ask("PIN"));
                System.out.println("  Logged in.");
            }
            case "0" -> {
                System.out.println("Goodbye!");
                return false;
            }
            default -> System.out.println("  Unknown option.");
        }
        return true;
    }

    private void loggedInMenu() {
        System.out.println("\n1) Open account  2) My accounts  3) Deposit  4) Withdraw");
        System.out.println("5) Balance  6) Mini statement  7) Apply monthly interest  8) Logout");
        switch (ask("Choose")) {
            case "1" -> {
                AccountType type = ask("Type (S = savings, C = current)").equalsIgnoreCase("S")
                        ? AccountType.SAVINGS : AccountType.CURRENT;
                Account a = bank.openAccount(token, type,
                        Validator.parseAmount(ask("Opening deposit")), newRequestId());
                System.out.println("  Opened " + a.getType() + " account " + a.getAccountNumber());
            }
            case "2" -> bank.listAccounts(token).forEach(a ->
                    System.out.println("  " + a.getAccountNumber() + "  " + a.getType()
                            + "  balance " + a.getBalance().toPlainString()));
            case "3" -> {
                String acc = ask("Account number");
                BigDecimal amt = Validator.parseAmount(ask("Amount"));
                Transaction t = bank.deposit(token, acc, amt, ask("Remarks (optional)"), newRequestId());
                System.out.println("  Deposited. New balance " + t.getBalanceAfter().toPlainString());
            }
            case "4" -> {
                String acc = ask("Account number");
                BigDecimal amt = Validator.parseAmount(ask("Amount"));
                Transaction t = bank.withdraw(token, acc, amt, ask("Remarks (optional)"), newRequestId());
                System.out.println("  Withdrawn. New balance " + t.getBalanceAfter().toPlainString());
            }
            case "5" -> System.out.println("  Balance: "
                    + bank.getBalance(token, ask("Account number")).toPlainString());
            case "6" -> {
                List<Transaction> list = bank.getMiniStatement(token, ask("Account number"), 10);
                list.forEach(t -> System.out.println("  " + t));
            }
            case "7" -> System.out.println("  Interest credited: "
                    + bank.applyMonthlyInterest(token, ask("Account number"), newRequestId()).toPlainString());
            case "8" -> {
                auth.logout(token);
                token = null;
                System.out.println("  Logged out.");
            }
            default -> System.out.println("  Unknown option.");
        }
    }

    /** One fresh id per user action; resubmitting the same id is blocked by the backend. */
    private static String newRequestId() {
        return UUID.randomUUID().toString();
    }

    private String ask(String prompt) {
        System.out.print(prompt + ": ");
        return in.hasNextLine() ? in.nextLine().trim() : "0";
    }
}
