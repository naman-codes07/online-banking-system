package com.naman.banking.service;

import com.naman.banking.exception.AuthenticationException;
import com.naman.banking.exception.InvalidInputException;
import com.naman.banking.model.User;
import com.naman.banking.util.Validator;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Registers users and logs them in (creating a session). */
public class AuthService {
    private final Map<String, User> usersByEmail = new ConcurrentHashMap<>();
    private final SessionManager sessions;

    public AuthService(SessionManager sessions) {
        this.sessions = sessions;
    }

    public User register(String name, String email, String pin) {
        User user = new User(name, email, pin); // validates everything
        if (usersByEmail.putIfAbsent(user.getEmail(), user) != null) {
            throw new InvalidInputException("An account with this e-mail already exists.");
        }
        return user;
    }

    /** Returns a session token. The same message is used for unknown e-mail and wrong PIN. */
    public String login(String email, String pin) {
        User user = email == null ? null : usersByEmail.get(email.trim().toLowerCase());
        if (user == null || !user.verifyPin(pin)) {
            throw new AuthenticationException("Invalid e-mail or PIN.");
        }
        return sessions.create(user).getToken();
    }

    public void logout(String token) {
        sessions.invalidate(token);
    }
}
