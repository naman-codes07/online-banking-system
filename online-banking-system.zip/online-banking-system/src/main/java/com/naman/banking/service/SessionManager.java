package com.naman.banking.service;

import com.naman.banking.exception.DuplicateRequestException;
import com.naman.banking.exception.SessionException;
import com.naman.banking.model.User;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Creates, validates and expires sessions (idle timeout). */
public class SessionManager {
    public static final Duration IDLE_TIMEOUT = Duration.ofMinutes(15);

    private final Map<String, Session> sessions = new ConcurrentHashMap<>();
    private final Clock clock;

    public SessionManager(Clock clock) {
        this.clock = clock;
    }

    public Session create(User user) {
        Session session = new Session(user, Instant.now(clock));
        sessions.put(session.getToken(), session);
        return session;
    }

    /** Returns the live session for a token or throws if it is unknown or idle too long. */
    public Session validate(String token) {
        Session session = token == null ? null : sessions.get(token);
        if (session == null) {
            throw new SessionException("Please log in first.");
        }
        Instant now = Instant.now(clock);
        if (Duration.between(session.getLastAccess(), now).compareTo(IDLE_TIMEOUT) > 0) {
            sessions.remove(token);
            throw new SessionException("Session expired. Please log in again.");
        }
        session.touch(now);
        return session;
    }

    /** Blocks duplicate submissions: each request id may be used once per session. */
    public void registerRequest(Session session, String requestId) {
        if (!session.registerRequest(requestId)) {
            throw new DuplicateRequestException("Duplicate request ignored (id " + requestId + ").");
        }
    }

    public void invalidate(String token) {
        if (token != null) {
            sessions.remove(token);
        }
    }
}
