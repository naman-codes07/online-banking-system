package com.naman.banking.model;

import com.naman.banking.exception.InsufficientFundsException;
import com.naman.banking.exception.TransactionLimitExceededException;
import com.naman.banking.util.Validator;

import java.math.BigDecimal;
import java.time.Clock;

/**
 * Current account: no interest, a high per-transaction limit and an overdraft
 * facility (the balance may go negative down to -OVERDRAFT_LIMIT).
 */
public class CurrentAccount extends Account {
    public static final BigDecimal OVERDRAFT_LIMIT = new BigDecimal("25000.00");
    public static final BigDecimal PER_TRANSACTION_LIMIT = new BigDecimal("200000.00");

    public CurrentAccount(String accountNumber, User owner, Clock clock) {
        super(accountNumber, owner, clock);
    }

    @Override
    public AccountType getType() {
        return AccountType.CURRENT;
    }

    @Override
    public synchronized Transaction withdraw(BigDecimal amount, String remarks) {
        BigDecimal valid = Validator.requireAmount(amount);

        if (valid.compareTo(PER_TRANSACTION_LIMIT) > 0) {
            throw new TransactionLimitExceededException(
                    "Per-transaction limit of " + PER_TRANSACTION_LIMIT + " exceeded.");
        }
        if (getBalance().subtract(valid).compareTo(OVERDRAFT_LIMIT.negate()) < 0) {
            throw new InsufficientFundsException(
                    "Overdraft limit of " + OVERDRAFT_LIMIT + " would be exceeded.");
        }
        return debit(valid, remarks);
    }

    @Override
    public BigDecimal applyMonthlyInterest() {
        return BigDecimal.ZERO.setScale(2); // current accounts earn no interest
    }
}
