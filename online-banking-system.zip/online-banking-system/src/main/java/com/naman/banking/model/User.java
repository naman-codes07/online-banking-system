package com.naman.banking.model;

import com.naman.banking.util.Validator;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.UUID;

/**
 * A bank customer. Fields are private; setters validate their input.
 * The PIN is never stored in plain text (salted SHA-256 - fine for a learning
 * project; a production system would use bcrypt/Argon2).
 */
public class User {
    private final String id = UUID.randomUUID().toString();
    private String name;
    private String email;
    private final byte[] salt = new byte[16];
    private byte[] pinHash;

    public User(String name, String email, String pin) {
        setName(name);
        setEmail(email);
        new SecureRandom().nextBytes(salt);
        changePin(pin);
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }

    public void setName(String name) {
        this.name = Validator.requireName(name);
    }

    public void setEmail(String email) {
        this.email = Validator.requireEmail(email);
    }

    public void changePin(String newPin) {
        this.pinHash = hash(Validator.requirePin(newPin));
    }

    public boolean verifyPin(String pin) {
        return pin != null && MessageDigest.isEqual(pinHash, hash(pin));
    }

    private byte[] hash(String pin) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(salt);
            return digest.digest(pin.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    @Override
    public String toString() {
        return name + " <" + email + ">";
    }
}
