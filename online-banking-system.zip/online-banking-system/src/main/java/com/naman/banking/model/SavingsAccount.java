package com.naman.banking.model;

import com.naman.banking.exception.InsufficientFundsException;
import com.naman.banking.exception.TransactionLimitExceededException;
import com.naman.banking.util.Validator;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;

/**
 * Savings account: must keep a minimum balance, has a daily withdrawal limit
 * and earns interest.
 */
public class SavingsAccount extends Account {
    public static final BigDecimal MINIMUM_BALANCE = new BigDecimal("500.00");
    public static final BigDecimal DAILY_WITHDRAWAL_LIMIT = new BigDecimal("50000.00");
    public static final BigDecimal ANNUAL_INTEREST_RATE = new BigDecimal("0.04"); // 4% p.a.

    public SavingsAccount(String accountNumber, User owner, Clock clock) {
        super(accountNumber, owner, clock);
    }

    @Override
    public AccountType getType() {
        return AccountType.SAVINGS;
    }

    @Override
    public synchronized Transaction withdraw(BigDecimal amount, String remarks) {
        BigDecimal valid = Validator.requireAmount(amount);

        if (withdrawnToday().add(valid).compareTo(DAILY_WITHDRAWAL_LIMIT) > 0) {
            throw new TransactionLimitExceededException(
                    "Daily withdrawal limit of " + DAILY_WITHDRAWAL_LIMIT + " exceeded.");
        }
        if (getBalance().subtract(valid).compareTo(MINIMUM_BALANCE) < 0) {
            throw new InsufficientFundsException(
                    "A minimum balance of " + MINIMUM_BALANCE + " must be maintained.");
        }
        return debit(valid, remarks);
    }

    @Override
    public synchronized BigDecimal applyMonthlyInterest() {
        BigDecimal interest = getBalance()
                .multiply(ANNUAL_INTEREST_RATE)
                .divide(BigDecimal.valueOf(12), 2, RoundingMode.HALF_UP);
        if (interest.signum() > 0) {
            creditInterest(interest);
        }
        return interest;
    }
}
