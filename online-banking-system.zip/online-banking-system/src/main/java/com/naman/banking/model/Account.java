package com.naman.banking.model;

import com.naman.banking.util.Validator;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Abstract base class for all accounts.
 *
 * <ul>
 *   <li><b>Encapsulation</b> - balance and history are private; the only way to change
 *       them is through the methods below.</li>
 *   <li><b>Thread safety</b> - every method that reads or writes the balance is
 *       {@code synchronized} on the account, so concurrent transactions cannot race.</li>
 *   <li><b>Polymorphism</b> - {@link #withdraw} and {@link #applyMonthlyInterest} are
 *       abstract: each account type enforces its own limits and interest rules.</li>
 *   <li><b>Overloading</b> - {@link #deposit(BigDecimal)} and
 *       {@link #deposit(BigDecimal, String)}.</li>
 * </ul>
 */
public abstract class Account {
    private final String accountNumber;
    private final User owner;
    private final Clock clock;
    private BigDecimal balance = BigDecimal.ZERO.setScale(2);
    private final List<Transaction> transactions = new ArrayList<>();

    protected Account(String accountNumber, User owner, Clock clock) {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.clock = clock;
    }

    // ------------------------------------------------------------ getters
    public String getAccountNumber() { return accountNumber; }
    public User getOwner() { return owner; }
    public abstract AccountType getType();

    public synchronized BigDecimal getBalance() {
        return balance;
    }

    /** Returns the most recent {@code count} transactions, newest first. */
    public synchronized List<Transaction> getRecentTransactions(int count) {
        int from = Math.max(0, transactions.size() - Math.max(count, 0));
        List<Transaction> recent = new ArrayList<>(transactions.subList(from, transactions.size()));
        Collections.reverse(recent);
        return recent;
    }

    // ------------------------------------------------------------ deposits (overloaded)
    public synchronized Transaction deposit(BigDecimal amount) {
        return deposit(amount, "Cash deposit");
    }

    public synchronized Transaction deposit(BigDecimal amount, String remarks) {
        BigDecimal valid = Validator.requireAmount(amount);
        return record(TransactionType.DEPOSIT, valid, balance.add(valid), Validator.cleanRemarks(remarks));
    }

    // ------------------------------------------------------------ account-specific rules
    /** Each account type applies its own withdrawal limits. Implementations must be synchronized. */
    public abstract Transaction withdraw(BigDecimal amount, String remarks);

    /** Each account type applies its own interest rule; returns the interest credited (may be zero). */
    public abstract BigDecimal applyMonthlyInterest();

    // ------------------------------------------------------------ helpers for subclasses
    /** Records the initial deposit when the account is opened. */
    public synchronized Transaction openWith(BigDecimal initialAmount) {
        BigDecimal valid = Validator.requireAmount(initialAmount);
        return record(TransactionType.OPENING_BALANCE, valid, balance.add(valid), "Account opening");
    }

    protected synchronized Transaction debit(BigDecimal amount, String remarks) {
        return record(TransactionType.WITHDRAWAL, amount, balance.subtract(amount), Validator.cleanRemarks(remarks));
    }

    protected synchronized Transaction creditInterest(BigDecimal interest) {
        return record(TransactionType.INTEREST, interest, balance.add(interest), "Monthly interest");
    }

    /** Total withdrawn today (clock's local date) - used for daily limits. */
    protected synchronized BigDecimal withdrawnToday() {
        LocalDate today = LocalDate.now(clock);
        ZoneId zone = clock.getZone();
        BigDecimal total = BigDecimal.ZERO;
        for (Transaction t : transactions) {
            if (t.getType() == TransactionType.WITHDRAWAL
                    && t.getTimestamp().atZone(zone).toLocalDate().equals(today)) {
                total = total.add(t.getAmount());
            }
        }
        return total;
    }

    private Transaction record(TransactionType type, BigDecimal amount, BigDecimal newBalance, String remarks) {
        this.balance = newBalance;
        Transaction t = new Transaction(accountNumber, type, amount, newBalance, remarks, Instant.now(clock));
        transactions.add(t);
        return t;
    }

    @Override
    public String toString() {
        return getType() + " " + accountNumber + " (" + owner.getName() + ")";
    }
}
