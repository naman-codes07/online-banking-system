package com.naman.banking.exception;

/** Session is missing, invalid or expired. */
public class SessionException extends BankingException {
    public SessionException(String message) {
        super(message);
    }
}
