package com.naman.banking.exception;

/** Base class for all domain errors in the banking system. */
public class BankingException extends RuntimeException {
    public BankingException(String message) {
        super(message);
    }
}
