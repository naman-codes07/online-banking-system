package com.naman.banking.service;

import com.naman.banking.exception.AccountNotFoundException;
import com.naman.banking.exception.InvalidInputException;
import com.naman.banking.model.Account;
import com.naman.banking.model.AccountType;
import com.naman.banking.model.CurrentAccount;
import com.naman.banking.model.SavingsAccount;
import com.naman.banking.model.Transaction;
import com.naman.banking.model.User;
import com.naman.banking.util.Validator;

import java.math.BigDecimal;
import java.time.Clock;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * In-memory implementation of {@link TransactionProcessor}.
 *
 * <p>Order of checks for every request: session valid -> inputs valid ->
 * account owned by the caller -> request id not seen before -> run the
 * (synchronized) account operation.
 */
public class BankingService implements TransactionProcessor {
    private final Map<String, Account> accounts = new ConcurrentHashMap<>();
    private final AtomicLong accountCounter = new AtomicLong(1_000_000_000L);
    private final SessionManager sessions;
    private final Clock clock;

    public BankingService(SessionManager sessions, Clock clock) {
        this.sessions = sessions;
        this.clock = clock;
    }

    @Override
    public Account openAccount(String token, AccountType type, BigDecimal initialDeposit, String requestId) {
        Session session = sessions.validate(token);
        if (type == null) {
            throw new InvalidInputException("Account type is required.");
        }
        BigDecimal initial = Validator.requireAmount(initialDeposit);
        if (type == AccountType.SAVINGS && initial.compareTo(SavingsAccount.MINIMUM_BALANCE) < 0) {
            throw new InvalidInputException(
                    "Savings accounts need an opening deposit of at least " + SavingsAccount.MINIMUM_BALANCE + ".");
        }
        sessions.registerRequest(session, Validator.requireRequestId(requestId));

        User owner = session.getUser();
        long n = accountCounter.incrementAndGet();
        Account account = (type == AccountType.SAVINGS)
                ? new SavingsAccount("SB" + n, owner, clock)
                : new CurrentAccount("CA" + n, owner, clock);
        account.openWith(initial);
        accounts.put(account.getAccountNumber(), account);
        return account;
    }

    @Override
    public Transaction deposit(String token, String accountNumber, BigDecimal amount,
                               String remarks, String requestId) {
        Session session = sessions.validate(token);
        BigDecimal valid = Validator.requireAmount(amount);
        String cleanRemarks = Validator.cleanRemarks(remarks);
        Account account = findOwned(session, accountNumber);
        sessions.registerRequest(session, Validator.requireRequestId(requestId));
        // Overloaded method: pick the variant that matches what the user supplied.
        return cleanRemarks.isEmpty() ? account.deposit(valid) : account.deposit(valid, cleanRemarks);
    }

    @Override
    public Transaction withdraw(String token, String accountNumber, BigDecimal amount,
                                String remarks, String requestId) {
        Session session = sessions.validate(token);
        BigDecimal valid = Validator.requireAmount(amount);
        String cleanRemarks = Validator.cleanRemarks(remarks);
        Account account = findOwned(session, accountNumber);
        sessions.registerRequest(session, Validator.requireRequestId(requestId));
        // Polymorphic call: SavingsAccount / CurrentAccount apply their own rules.
        return account.withdraw(valid, cleanRemarks.isEmpty() ? "Cash withdrawal" : cleanRemarks);
    }

    @Override
    public BigDecimal getBalance(String token, String accountNumber) {
        return findOwned(sessions.validate(token), accountNumber).getBalance();
    }

    @Override
    public List<Transaction> getMiniStatement(String token, String accountNumber, int count) {
        return findOwned(sessions.validate(token), accountNumber).getRecentTransactions(count);
    }

    @Override
    public BigDecimal applyMonthlyInterest(String token, String accountNumber, String requestId) {
        Session session = sessions.validate(token);
        Account account = findOwned(session, accountNumber);
        sessions.registerRequest(session, Validator.requireRequestId(requestId));
        return account.applyMonthlyInterest(); // polymorphic
    }

    @Override
    public List<Account> listAccounts(String token) {
        User user = sessions.validate(token).getUser();
        List<Account> mine = new ArrayList<>();
        for (Account a : accounts.values()) {
            if (a.getOwner().getId().equals(user.getId())) {
                mine.add(a);
            }
        }
        mine.sort((a, b) -> a.getAccountNumber().compareTo(b.getAccountNumber()));
        return mine;
    }

    /** Same error for "missing" and "someone else's" so account numbers cannot be probed. */
    private Account findOwned(Session session, String accountNumber) {
        Account account = accountNumber == null ? null : accounts.get(accountNumber.trim().toUpperCase());
        if (account == null || !account.getOwner().getId().equals(session.getUser().getId())) {
            throw new AccountNotFoundException("Account not found: " + accountNumber);
        }
        return account;
    }
}
