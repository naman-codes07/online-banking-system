package com.naman.banking.exception;

/** The same request id was submitted more than once. */
public class DuplicateRequestException extends BankingException {
    public DuplicateRequestException(String message) {
        super(message);
    }
}
