package com.naman.banking;

import com.naman.banking.exception.*;
import com.naman.banking.model.*;
import com.naman.banking.service.*;

import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Dependency-free test runner (no JUnit needed): run with
 *   java -cp out com.naman.banking.BankingTests
 */
public class BankingTests {

    // ---------- tiny test harness ----------
    private static int passed = 0, failed = 0;

    interface Body { void run() throws Exception; }

    static void test(String name, Body body) {
        try {
            body.run();
            passed++;
            System.out.println("  PASS  " + name);
        } catch (Throwable t) {
            failed++;
            System.out.println("  FAIL  " + name + "  ->  " + t);
        }
    }

    static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    static void eq(Object expected, Object actual) {
        if (!Objects.equals(expected, actual)) {
            throw new AssertionError("expected <" + expected + "> but was <" + actual + ">");
        }
    }

    static <T extends Throwable> void throwsEx(Class<T> type, Body body) {
        try {
            body.run();
        } catch (Throwable t) {
            if (type.isInstance(t)) return;
            throw new AssertionError("expected " + type.getSimpleName() + " but got " + t);
        }
        throw new AssertionError("expected " + type.getSimpleName() + " but nothing was thrown");
    }

    static BigDecimal d(String s) { return new BigDecimal(s); }

    /** Clock tests can move forward. */
    static class MutableClock extends Clock {
        private volatile Instant now = Instant.parse("2025-01-15T10:00:00Z");
        public void advance(Duration d) { now = now.plus(d); }
        @Override public ZoneId getZone() { return ZoneOffset.UTC; }
        @Override public Clock withZone(ZoneId zone) { return this; }
        @Override public Instant instant() { return now; }
    }

    // ---------- fixture ----------
    static class Fixture {
        final MutableClock clock = new MutableClock();
        final SessionManager sessions = new SessionManager(clock);
        final AuthService auth = new AuthService(sessions);
        final TransactionProcessor bank = new BankingService(sessions, clock);

        String login(String name, String email) {
            auth.register(name, email, "1234");
            return auth.login(email, "1234");
        }
        static String rid() { return UUID.randomUUID().toString(); }

        String open(String token, AccountType type, String initial) {
            return bank.openAccount(token, type, d(initial), rid()).getAccountNumber();
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("Running tests...\n");

        // ----- basic operations -----
        test("deposit, withdraw and balance on a savings account", () -> {
            Fixture f = new Fixture();
            String t = f.login("Asha Rao", "asha@example.com");
            String acc = f.open(t, AccountType.SAVINGS, "1000");
            f.bank.deposit(t, acc, d("500"), "salary", Fixture.rid());
            f.bank.withdraw(t, acc, d("200"), "", Fixture.rid());
            eq(d("1300.00"), f.bank.getBalance(t, acc));
            eq(3, f.bank.getMiniStatement(t, acc, 10).size());
        });

        test("overloaded deposit(amount) and deposit(amount, remarks)", () -> {
            User u = new User("Ravi Kumar", "ravi@example.com", "4321");
            Account a = new SavingsAccount("SB1", u, new MutableClock());
            eq("Cash deposit", a.deposit(d("100")).getRemarks());
            eq("bonus", a.deposit(d("50"), "bonus").getRemarks());
            eq(d("150.00"), a.getBalance());
        });

        // ----- polymorphism -----
        test("savings: minimum balance is enforced", () -> {
            Fixture f = new Fixture();
            String t = f.login("Asha Rao", "asha@example.com");
            String acc = f.open(t, AccountType.SAVINGS, "1000");
            throwsEx(InsufficientFundsException.class,
                    () -> f.bank.withdraw(t, acc, d("501"), "", Fixture.rid()));
            f.bank.withdraw(t, acc, d("500"), "", Fixture.rid()); // leaves exactly 500
            eq(d("500.00"), f.bank.getBalance(t, acc));
        });

        test("savings: daily withdrawal limit, resets the next day", () -> {
            User u = new User("Asha Rao", "asha@example.com", "1234");
            MutableClock clock = new MutableClock();          // starts 2025-01-15 10:00 UTC
            SavingsAccount acc = new SavingsAccount("SB1", u, clock);
            acc.openWith(d("200000"));
            acc.withdraw(d("30000"), "");
            throwsEx(TransactionLimitExceededException.class, () -> acc.withdraw(d("20001"), ""));
            acc.withdraw(d("20000"), "");                     // exactly at the 50,000 limit
            throwsEx(TransactionLimitExceededException.class, () -> acc.withdraw(d("1"), ""));
            clock.advance(Duration.ofHours(14));              // -> 2025-01-16 00:00 UTC
            acc.withdraw(d("50000"), "");                     // new day, limit is fresh
            eq(d("100000.00"), acc.getBalance());
        });

        test("current: overdraft allowed up to its limit", () -> {
            Fixture f = new Fixture();
            String t = f.login("Meera Shah", "meera@example.com");
            String acc = f.open(t, AccountType.CURRENT, "1000");
            f.bank.withdraw(t, acc, d("26000"), "", Fixture.rid()); // balance -25000
            eq(d("-25000.00"), f.bank.getBalance(t, acc));
            throwsEx(InsufficientFundsException.class,
                    () -> f.bank.withdraw(t, acc, d("1"), "", Fixture.rid()));
        });

        test("current: per-transaction limit", () -> {
            Fixture f = new Fixture();
            String t = f.login("Meera Shah", "meera@example.com");
            String acc = f.open(t, AccountType.CURRENT, "500000");
            throwsEx(TransactionLimitExceededException.class,
                    () -> f.bank.withdraw(t, acc, d("200000.01"), "", Fixture.rid()));
        });

        test("interest rule differs per account type (polymorphic call)", () -> {
            User u = new User("Ravi Kumar", "ravi@example.com", "4321");
            MutableClock c = new MutableClock();
            List<Account> accounts = List.of(new SavingsAccount("SB1", u, c), new CurrentAccount("CA1", u, c));
            for (Account a : accounts) a.openWith(d("12000"));
            eq(d("40.00"), accounts.get(0).applyMonthlyInterest());   // 12000 * 4% / 12
            eq(d("0.00"), accounts.get(1).applyMonthlyInterest());
            eq(d("12040.00"), accounts.get(0).getBalance());
            eq(d("12000.00"), accounts.get(1).getBalance());
        });

        // ----- validation -----
        test("invalid amounts are rejected", () -> {
            Fixture f = new Fixture();
            String t = f.login("Asha Rao", "asha@example.com");
            String acc = f.open(t, AccountType.SAVINGS, "1000");
            throwsEx(InvalidInputException.class, () -> f.bank.deposit(t, acc, d("0"), "", Fixture.rid()));
            throwsEx(InvalidInputException.class, () -> f.bank.deposit(t, acc, d("-5"), "", Fixture.rid()));
            throwsEx(InvalidInputException.class, () -> f.bank.deposit(t, acc, d("1.234"), "", Fixture.rid()));
            throwsEx(InvalidInputException.class, () -> f.bank.deposit(t, acc, null, "", Fixture.rid()));
            throwsEx(InvalidInputException.class, () -> f.bank.deposit(t, acc, d("10000001"), "", Fixture.rid()));
            eq(d("1000.00"), f.bank.getBalance(t, acc));
        });

        test("invalid user data is rejected by validated setters", () -> {
            throwsEx(InvalidInputException.class, () -> new User("X", "a@b.com", "1234"));
            throwsEx(InvalidInputException.class, () -> new User("Asha Rao", "not-an-email", "1234"));
            throwsEx(InvalidInputException.class, () -> new User("Asha Rao", "a@b.com", "12"));
            User u = new User("Asha Rao", "a@b.com", "1234");
            throwsEx(InvalidInputException.class, () -> u.setName("<script>"));
        });

        test("savings account needs a minimum opening deposit", () -> {
            Fixture f = new Fixture();
            String t = f.login("Asha Rao", "asha@example.com");
            throwsEx(InvalidInputException.class, () -> f.open(t, AccountType.SAVINGS, "499"));
        });

        // ----- duplicate submissions & sessions -----
        test("duplicate request id is blocked (money moves once)", () -> {
            Fixture f = new Fixture();
            String t = f.login("Asha Rao", "asha@example.com");
            String acc = f.open(t, AccountType.SAVINGS, "1000");
            String id = Fixture.rid();
            f.bank.deposit(t, acc, d("100"), "", id);
            throwsEx(DuplicateRequestException.class, () -> f.bank.deposit(t, acc, d("100"), "", id));
            eq(d("1100.00"), f.bank.getBalance(t, acc));
        });

        test("20 threads submitting the SAME request id -> exactly one succeeds", () -> {
            Fixture f = new Fixture();
            String t = f.login("Asha Rao", "asha@example.com");
            String acc = f.open(t, AccountType.SAVINGS, "1000");
            String id = Fixture.rid();
            ExecutorService pool = Executors.newFixedThreadPool(20);
            CountDownLatch start = new CountDownLatch(1);
            AtomicInteger ok = new AtomicInteger(), dup = new AtomicInteger();
            List<Future<?>> fs = new ArrayList<>();
            for (int i = 0; i < 20; i++) {
                fs.add(pool.submit(() -> {
                    start.await();
                    try { f.bank.deposit(t, acc, d("100"), "", id); ok.incrementAndGet(); }
                    catch (DuplicateRequestException e) { dup.incrementAndGet(); }
                    return null;
                }));
            }
            start.countDown();
            for (Future<?> x : fs) x.get();
            pool.shutdown();
            eq(1, ok.get());
            eq(19, dup.get());
            eq(d("1100.00"), f.bank.getBalance(t, acc));
        });

        test("session expires after idle timeout; activity keeps it alive", () -> {
            Fixture f = new Fixture();
            String t = f.login("Asha Rao", "asha@example.com");
            String acc = f.open(t, AccountType.SAVINGS, "1000");
            f.clock.advance(Duration.ofMinutes(10));
            f.bank.getBalance(t, acc);                       // activity -> refreshed
            f.clock.advance(Duration.ofMinutes(10));
            f.bank.getBalance(t, acc);                       // still alive (10 min since last use)
            f.clock.advance(Duration.ofMinutes(16));
            throwsEx(SessionException.class, () -> f.bank.getBalance(t, acc));
        });

        test("no session / logged-out token is rejected", () -> {
            Fixture f = new Fixture();
            String t = f.login("Asha Rao", "asha@example.com");
            String acc = f.open(t, AccountType.SAVINGS, "1000");
            f.auth.logout(t);
            throwsEx(SessionException.class, () -> f.bank.getBalance(t, acc));
            throwsEx(SessionException.class, () -> f.bank.getBalance(null, acc));
        });

        test("users cannot touch each other's accounts", () -> {
            Fixture f = new Fixture();
            String a = f.login("Asha Rao", "asha@example.com");
            String b = f.login("Ravi Kumar", "ravi@example.com");
            String accA = f.open(a, AccountType.SAVINGS, "1000");
            throwsEx(AccountNotFoundException.class, () -> f.bank.getBalance(b, accA));
            throwsEx(AccountNotFoundException.class, () -> f.bank.withdraw(b, accA, d("10"), "", Fixture.rid()));
        });

        test("login: wrong PIN and unknown e-mail give the same error; duplicate e-mail rejected", () -> {
            Fixture f = new Fixture();
            f.auth.register("Asha Rao", "asha@example.com", "1234");
            throwsEx(AuthenticationException.class, () -> f.auth.login("asha@example.com", "9999"));
            throwsEx(AuthenticationException.class, () -> f.auth.login("nobody@example.com", "1234"));
            throwsEx(InvalidInputException.class, () -> f.auth.register("Asha Rao", "ASHA@example.com", "1234"));
        });

        // ----- concurrency -----
        test("concurrency: 50 threads x 100 deposits of 10 -> exact total", () -> {
            Fixture f = new Fixture();
            String t = f.login("Asha Rao", "asha@example.com");
            String acc = f.open(t, AccountType.SAVINGS, "1000");
            int threads = 50, perThread = 100;
            ExecutorService pool = Executors.newFixedThreadPool(threads);
            CountDownLatch start = new CountDownLatch(1);
            List<Future<?>> fs = new ArrayList<>();
            for (int i = 0; i < threads; i++) {
                fs.add(pool.submit(() -> {
                    start.await();
                    for (int j = 0; j < perThread; j++) f.bank.deposit(t, acc, d("10"), "", Fixture.rid());
                    return null;
                }));
            }
            start.countDown();
            for (Future<?> x : fs) x.get();
            pool.shutdown();
            eq(d("51000.00"), f.bank.getBalance(t, acc));           // 1000 + 50*100*10
            eq(5001, f.bank.getMiniStatement(t, acc, 100000).size());
        });

        test("concurrency: racing withdrawals never break the minimum balance", () -> {
            User u = new User("Asha Rao", "asha@example.com", "1234");
            SavingsAccount acc = new SavingsAccount("SB1", u, new MutableClock());
            acc.openWith(d("1000")); // only 500 may leave (min balance 500)
            ExecutorService pool = Executors.newFixedThreadPool(30);
            CountDownLatch start = new CountDownLatch(1);
            AtomicInteger success = new AtomicInteger();
            List<Future<?>> fs = new ArrayList<>();
            for (int i = 0; i < 30; i++) {
                fs.add(pool.submit(() -> {
                    start.await();
                    try { acc.withdraw(d("100"), "race"); success.incrementAndGet(); }
                    catch (InsufficientFundsException ignored) { }
                    return null;
                }));
            }
            start.countDown();
            for (Future<?> x : fs) x.get();
            pool.shutdown();
            eq(5, success.get());                    // exactly 5 x 100 fit above the minimum
            eq(d("500.00"), acc.getBalance());
        });

        System.out.printf("%n%d passed, %d failed%n", passed, failed);
        if (failed > 0) System.exit(1);
    }
}
