# Online Banking System (Java)

A console-based banking application written in core Java. It supports savings
and current accounts with deposits, withdrawals and balance checks, and is
built to demonstrate object-oriented design, input validation, session
handling and thread-safe transaction processing. No external libraries are
needed.

## Features

- **Accounts:** open savings or current accounts; deposit, withdraw, check balance, view mini statement, apply monthly interest
- **Input validation:** names, e-mails, PINs, amounts (positive, max 2 decimals, upper cap) and remarks are validated in one place (`Validator`)
- **Session handling:** login creates a session with an idle timeout (15 min); every call needs a valid session token
- **Duplicate-submission protection:** each money-moving request carries a unique request id; a repeated id is rejected, even when many threads send it at the same time
- **Thread safety:** account methods are `synchronized`, so concurrent transactions cannot cause race conditions and balances stay accurate
- **Security basics:** PINs are stored as salted hashes; users can only access their own accounts; login errors do not reveal whether an e-mail exists

## Account rules (demonstrating polymorphism)

| | Savings | Current |
|---|---|---|
| Opening deposit | at least 500.00 | any positive amount |
| Withdrawal rule | must keep a 500.00 minimum balance | overdraft allowed down to -25,000.00 |
| Limit | 50,000.00 per day | 200,000.00 per transaction |
| Interest | 4% p.a., credited monthly | none |

## OOP concepts used

| Concept | Where |
|---|---|
| Encapsulation | `Account`, `User` and `Transaction` have private fields; `User` setters validate input; balance can only change through account methods |
| Inheritance | abstract `Account` is extended by `SavingsAccount` and `CurrentAccount` |
| Polymorphism (overriding) | `withdraw()` and `applyMonthlyInterest()` are abstract in `Account` and implemented differently per account type |
| Polymorphism (overloading) | `deposit(amount)` and `deposit(amount, remarks)` |
| Interface / loose coupling | `TransactionProcessor` is the only thing the UI (`Main`) knows about; `BankingService` is one in-memory implementation |
| Concurrency | `synchronized` methods in `Account`, atomic request-id registration in `Session`, concurrent maps in the services |
| Custom exceptions | `InsufficientFundsException`, `DuplicateRequestException`, `SessionException`, ... |

## Project structure

```
online-banking-system/
├── src/main/java/com/naman/banking/
│   ├── Main.java                      # console UI
│   ├── model/                         # Account, SavingsAccount, CurrentAccount, User, Transaction, enums
│   ├── service/                       # TransactionProcessor (interface), BankingService, AuthService,
│   │                                  # SessionManager, Session
│   ├── exception/                     # custom exceptions
│   └── util/Validator.java            # all input validation
├── src/test/java/com/naman/banking/
│   └── BankingTests.java              # 18 tests, no framework needed
├── .gitignore
├── LICENSE
└── README.md
```

## Getting started

Requires **JDK 17 or newer**.

```bash
git clone https://github.com/naman-codes07/online-banking-system.git
cd online-banking-system

# compile
mkdir out
javac -d out $(find src -name "*.java")      # Windows (PowerShell): javac -d out (Get-ChildItem -Recurse src -Filter *.java).FullName

# run the app
java -cp out com.naman.banking.Main

# run the tests
java -cp out com.naman.banking.BankingTests
```

You can also open the folder in IntelliJ IDEA / VS Code / Eclipse and run `Main`.

## Sample session

```
=== Online Banking System ===
1) Register   2) Login   0) Exit
Choose: 1
Full name: Asha Rao
E-mail: asha@example.com
PIN (4-6 digits): 1234
  Registered. You can log in now.
...
Choose: 1                       # open account
Type (S = savings, C = current): S
Opening deposit: 1000
  Opened SAVINGS account SB1000000001
...
Choose: 4                       # withdraw
Amount: 99999
  ! Daily withdrawal limit of 50000.00 exceeded.
```

## What the tests cover

- deposits, withdrawals, balances, mini statement
- savings minimum balance, daily limit (including next-day reset), current-account overdraft and per-transaction limit
- different interest behaviour through the same `Account` type
- invalid amounts, names, e-mails and PINs
- duplicate request ids, including 20 threads sending the same id (exactly one succeeds)
- session idle timeout, logout, and access to other users' accounts
- 50 threads x 100 deposits give the exact expected total; racing withdrawals never break the minimum balance

## Limitations and ideas for improvement

- Data is kept in memory only, so it is lost when the app exits. A database layer (JDBC / JPA) would be the next step: implement `TransactionProcessor` with a database-backed class.
- Fund transfers between accounts (needs consistent lock ordering to avoid deadlocks).
- Stronger password hashing (bcrypt / Argon2) and login attempt limits.
- A REST or web front end using the same `TransactionProcessor` interface.

This is a learning project, not production banking software.

## Author

**Naman Upadhyay** - [GitHub](https://github.com/naman-codes07) | [LinkedIn](https://linkedin.com/in/naman-upadhyay)

Licensed under the MIT License.
